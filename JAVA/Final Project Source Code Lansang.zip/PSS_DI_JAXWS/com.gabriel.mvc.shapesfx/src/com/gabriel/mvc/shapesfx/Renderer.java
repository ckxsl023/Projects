package com.gabriel.mvc.shapesfx;

public interface Renderer {
	void draw(Object context, MyShape shape);
}
