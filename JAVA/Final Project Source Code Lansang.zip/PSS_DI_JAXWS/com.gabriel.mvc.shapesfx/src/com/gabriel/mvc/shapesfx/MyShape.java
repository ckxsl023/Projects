package com.gabriel.mvc.shapesfx;

public interface MyShape {
	Location getLocation();
	void setLocation(Location location);
}
