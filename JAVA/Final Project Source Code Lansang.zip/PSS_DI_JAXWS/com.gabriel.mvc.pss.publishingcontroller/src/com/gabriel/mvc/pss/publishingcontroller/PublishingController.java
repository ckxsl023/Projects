package com.gabriel.mvc.pss.publishingcontroller;

public class PublishingController {

	public static void main(String[] args) {
		CarController carController = new CarController();
		carController.init();
		carController.initUI();
	}

}
