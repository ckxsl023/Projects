package com.gabriel.guiApp;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import com.gabriel.guiImpl.Car;
import com.gabriel.guiMover.CarMover;
import com.gabriel.guiRenderer.CarRenderer;

public class Draw extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Car car;
	@Override
	public void paintComponent(Graphics g) {
	     super.paintComponent(g);
	     CarRenderer renderCar=new CarRenderer();
	     renderCar.draw(g, car);
	    
	}
	
	public void init() {
		JButton button=new JButton("-->");
		button.setBounds(200, 380, 30, 20);
		button.setVisible(true);
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				CarMover carMover=new CarMover();
				carMover.move(car, 10, 0, 0);
				repaint();
				
			}
		});
		add(button);
	}
	public Car getCar() {
		return car;
	}
	public void setCar(Car car) {
		this.car = car;
	}
	
}
