package com.gabriel.guiApp;

import java.awt.Color;

import javax.annotation.Resource;
import javax.swing.JFrame;

import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.*;

import com.gabriel.guiImpl.Car;  


public class MainApp extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		MainApp mainApp=new MainApp();
		mainApp.setTitle("Draw");
		mainApp.setBounds(10,10, 400, 400);
		Draw draw= new Draw();
		draw.setBounds(0,0, 80,80);
		draw.setBackground(Color.blue);
		draw.setForeground(Color.white);
		draw.init();
		mainApp.add(draw);
		//Car car=new Car(new Rectangle(new Location(20,20),50,20), new Circle(new Location(22,35),10),new Circle(new Location(50,35),10));
		
		ClassPathResource r= new ClassPathResource("ApplicationContext.xml");  
        BeanFactory factory=new XmlBeanFactory((org.springframework.core.io.Resource) r);  
        
        Car car=(Car) factory.getBean("car");
		
        draw.setCar(car);
		mainApp.setVisible(true);
	
	}
}
