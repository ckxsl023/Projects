package com.gabriel.guiFx;

public interface Renderer {
	void draw(Object object, Shape shape);
}
