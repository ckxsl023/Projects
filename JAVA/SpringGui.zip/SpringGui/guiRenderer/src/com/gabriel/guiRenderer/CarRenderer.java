package com.gabriel.guiRenderer;

import java.awt.Graphics;

import com.gabriel.guiFx.Renderer;
import com.gabriel.guiFx.Shape;
import com.gabriel.guiImpl.Car;
import com.gabriel.guiImpl.Circle;
import com.gabriel.guiImpl.Rectangle;

public class CarRenderer implements Renderer{

	@Override
	public void draw(Object object, Shape shape) {
		Graphics g=(Graphics) object;
		Car car=(Car) shape;
		
		Rectangle body = car.getBody();
		Circle rear = car.getRear();
		Circle front = car.getFront();
		
		RectangleRenderer rectRenderer=new RectangleRenderer();
		CircleRenderer circleRenderer=new CircleRenderer();
		rectRenderer.draw(object, body);
		circleRenderer.draw(object, front);
		circleRenderer.draw(object, rear);
	
	}

}
