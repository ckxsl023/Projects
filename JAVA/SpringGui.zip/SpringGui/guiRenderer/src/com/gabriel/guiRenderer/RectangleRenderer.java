package com.gabriel.guiRenderer;

import java.awt.Graphics;

import com.gabriel.guiFx.Renderer;
import com.gabriel.guiFx.Shape;
import com.gabriel.guiImpl.Rectangle;

public class RectangleRenderer implements Renderer{

	@Override
	public void draw(Object object, Shape shape) {
		Graphics g = (Graphics) object;
		Rectangle rectangle=(Rectangle) shape;
		g.drawRect(rectangle.getLocation().getX(), rectangle.getLocation().getY(), rectangle.getWidth(), rectangle.getHeight());
	}

}
