package com.gabriel.guiImpl;

import com.gabriel.guiFx.BaseShape;

public class Car extends BaseShape{
	private Circle front;
	private Circle rear;
    private Rectangle body;
    
	public Circle getFront() {
		return front;
	}
	public void setFront(Circle front) {
		this.front = front;
	}
	public Circle getRear() {
		return rear;
	}
	public void setRear(Circle rear) {
		this.rear = rear;
	}
	public Rectangle getBody() {
		return body;
	}
	public void setBody(Rectangle body) {
		this.body = body;
	}
    
    
	
}
