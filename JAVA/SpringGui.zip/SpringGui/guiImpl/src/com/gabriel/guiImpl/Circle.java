package com.gabriel.guiImpl;

import com.gabriel.guiFx.BaseShape;

public class Circle extends BaseShape {
	private int radius;

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
}
