package com.gabriel.guiMover;

import com.gabriel.guiFx.Mover;
import com.gabriel.guiFx.Shape;
import com.gabriel.guiImpl.Circle;
import com.gabriel.guiImpl.Rectangle;

public class RectangleMover implements Mover{
	@Override
	public void move(Shape shape, int dx, int dy, int dz) {
		Rectangle rectangle = (Rectangle) shape;
		rectangle.getLocation().setX(rectangle.getLocation().getX()+dx);
		rectangle.getLocation().setY(rectangle.getLocation().getY()+dy);
	}
}
