package com.gabriel.guiMover;



import com.gabriel.guiFx.Mover;
import com.gabriel.guiFx.Shape;
import com.gabriel.guiImpl.Car;
import com.gabriel.guiImpl.Circle;
import com.gabriel.guiImpl.Rectangle;

public class CarMover implements Mover {

	@Override
	public void move(Shape shape, int dx, int dy, int dz) {
		Car car = (Car) shape;
		Rectangle body = car.getBody();
		RectangleMover rectangleMover=new RectangleMover();
		rectangleMover.move(body, dx, dy, dz);
		
		Circle front = car.getFront();
		CircleMover circleMover=new CircleMover();
		circleMover.move(front, dx, dy, dz);
		
		Circle rear = car.getRear();
		circleMover.move(rear, dx, dy, dz);
		
		
	}

}
